Instructions moved to
[docs/how_to_create_plugin.md](docs/how_to_create_plugin.md).
